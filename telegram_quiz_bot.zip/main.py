#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Academic Quiz Bot for Telegram
------------------------------
A bot that delivers structured academic quizzes with a competitive leaderboard system.
"""

import os
import json
import logging
import time
from datetime import datetime
from pathlib import Path
import random
from threading import Timer

from telegram import (
    Update, 
    InlineKeyboardButton, 
    InlineKeyboardMarkup,
    ParseMode
)
from telegram.ext import (
    Updater,
    CommandHandler,
    CallbackQueryHandler,
    CallbackContext,
    ConversationHandler,
    MessageHandler,
    Filters
)

# Enable logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO
)
logger = logging.getLogger(__name__)

# Define conversation states
MAIN_MENU, SUBJECT_SELECTION, LECTURE_SELECTION, QUIZ_RUNNING = range(4)

# Define paths
BASE_DIR = Path(__file__).resolve().parent
QUIZ_DATA_DIR = BASE_DIR / "quiz_data"
QUESTIONS_DIR = QUIZ_DATA_DIR / "questions"
LEADERBOARD_FILE = QUIZ_DATA_DIR / "leaderboard.json"

# Ensure directories exist
QUIZ_DATA_DIR.mkdir(exist_ok=True)
QUESTIONS_DIR.mkdir(exist_ok=True)

# Global variables to track active quizzes
active_quizzes = {}  # user_id -> quiz_data
question_timers = {}  # user_id -> timer object

# Default subjects
DEFAULT_SUBJECTS = [
    "Internet Technology",
    "Software Engineering",
    "Data Structures",
    "Algorithms",
    "Computer Networks"
]

# Default number of lectures per subject
DEFAULT_LECTURES_PER_SUBJECT = 14

# Default number of questions per lecture
DEFAULT_QUESTIONS_PER_LECTURE = 10

# Question timer duration in seconds
QUESTION_TIMER_DURATION = 30

# Egyptian Arabic humor responses for different score ranges
SCORE_RESPONSES = {
    "perfect": [
        "مبروك يا نجم! 🌟 انت دلوقتي في المركز {position} على لوحة المتصدرين!",
        "عاش يا بطل! 🚀 انت حاليًا في المركز {position} على لوحة المتصدرين!",
        "تمام التمام! 💯 انت دلوقتي في المركز {position} على لوحة المتصدرين!"
    ],
    "good": [
        "شغل عالي! 👏 استمر كده!",
        "برافو عليك! 🔥 شغل جامد!",
        "ماشي تمام! 👍 في تقدم واضح!"
    ],
    "average": [
        "مش وحش! 🙂 في مجال للتحسين.",
        "ماشي الحال! 😊 استمر في المذاكرة.",
        "نص نص! 🤔 ممكن تعمل أحسن من كده."
    ],
    "poor": [
        "معلش يا صاحبي، المرة الجاية هتعمل أحسن! 🙃",
        "خليك فاكر، المذاكرة هي السر! 📚",
        "مفيش مشكلة، استمر في المحاولة! 💪"
    ]
}

def init_quiz_data():
    """Initialize quiz data structure if it doesn't exist."""
    # Create subject directories
    for subject in DEFAULT_SUBJECTS:
        subject_dir = QUESTIONS_DIR / subject.lower().replace(" ", "_")
        subject_dir.mkdir(exist_ok=True)
        
        # Create lecture files with sample questions
        for lecture_num in range(1, DEFAULT_LECTURES_PER_SUBJECT + 1):
            lecture_file = subject_dir / f"lecture{lecture_num}.json"
            
            if not lecture_file.exists():
                # Generate sample questions for this lecture
                questions = generate_sample_questions(subject, lecture_num)
                
                lecture_data = {
                    "lecture": lecture_num,
                    "questions": questions
                }
                
                with open(lecture_file, 'w', encoding='utf-8') as f:
                    json.dump(lecture_data, f, indent=2, ensure_ascii=False)
    
    # Initialize leaderboard if it doesn't exist
    if not LEADERBOARD_FILE.exists():
        current_month = datetime.now().strftime("%Y-%B")
        leaderboard_data = {
            "version": current_month,
            "users": {}
        }
        with open(LEADERBOARD_FILE, 'w', encoding='utf-8') as f:
            json.dump(leaderboard_data, f, indent=2, ensure_ascii=False)

def generate_sample_questions(subject, lecture_num):
    """Generate sample questions for a subject and lecture."""
    questions = []
    
    # Define question templates based on subject
    templates = {
        "Internet Technology": [
            "What is the primary function of {concept}?",
            "Which protocol is used for {concept}?",
            "What layer of the OSI model does {concept} operate on?",
            "Who developed {concept}?",
            "When was {concept} first introduced?",
            "What is the difference between {concept} and {alt_concept}?",
            "Which of the following is NOT a feature of {concept}?",
            "What security concerns are associated with {concept}?",
            "How does {concept} contribute to web performance?",
            "What is the future of {concept} in modern web development?"
        ],
        "Software Engineering": [
            "Which software development methodology emphasizes {concept}?",
            "What is the main purpose of {concept} in software development?",
            "Who is credited with developing the {concept} principle?",
            "In which phase of the software development lifecycle is {concept} most important?",
            "What is the relationship between {concept} and {alt_concept}?",
            "Which of these is NOT a principle of {concept}?",
            "How does {concept} improve code maintainability?",
            "What tool is commonly used for implementing {concept}?",
            "What is a common challenge when implementing {concept}?",
            "How has {concept} evolved in modern software engineering practices?"
        ],
        "Data Structures": [
            "What is the time complexity for searching in a {concept}?",
            "Which operation is most efficient in a {concept}?",
            "When would you choose a {concept} over a {alt_concept}?",
            "What is the space complexity of {concept}?",
            "Which of these is NOT a valid operation on a {concept}?",
            "How is a {concept} typically implemented?",
            "What is a practical application of {concept}?",
            "Who first described the {concept} data structure?",
            "What is the worst-case scenario for {concept} performance?",
            "How does {concept} handle duplicate values?"
        ],
        "Algorithms": [
            "What is the time complexity of {concept}?",
            "Which problem is best solved using {concept}?",
            "What is the key principle behind {concept}?",
            "Who developed the {concept} algorithm?",
            "When would {concept} perform better than {alt_concept}?",
            "What is a limitation of the {concept} algorithm?",
            "Which data structure works best with {concept}?",
            "What optimization can improve {concept} performance?",
            "In which scenario would {concept} fail?",
            "How does {concept} handle worst-case inputs?"
        ],
        "Computer Networks": [
            "What is the primary purpose of {concept} in networking?",
            "Which layer of the TCP/IP model includes {concept}?",
            "What protocol is associated with {concept}?",
            "How does {concept} ensure reliable data transmission?",
            "What is the difference between {concept} and {alt_concept}?",
            "Which of these is NOT a feature of {concept}?",
            "What security mechanism is used in {concept}?",
            "How has {concept} evolved in modern networking?",
            "What is the maximum transmission unit for {concept}?",
            "Which organization standardized {concept}?"
        ]
    }
    
    # Define concepts for each subject
    concepts = {
        "Internet Technology": [
            "HTTP", "HTTPS", "DNS", "TCP/IP", "REST API", "WebSockets", 
            "HTTP/2", "HTTP/3", "CDN", "SSL/TLS", "Cookies", "Web Caching",
            "AJAX", "JSON", "XML", "URI", "URL", "Domain Names", "IP Addressing",
            "Load Balancing", "Web Servers", "Proxy Servers", "Firewalls"
        ],
        "Software Engineering": [
            "Agile", "Scrum", "Waterfall", "DevOps", "CI/CD", "TDD", "BDD",
            "Version Control", "Git", "Code Reviews", "Pair Programming",
            "Refactoring", "Design Patterns", "SOLID Principles", "DRY Principle",
            "Technical Debt", "User Stories", "Requirements Engineering",
            "Software Testing", "UML", "Software Architecture", "Microservices"
        ],
        "Data Structures": [
            "Arrays", "Linked Lists", "Stacks", "Queues", "Hash Tables",
            "Trees", "Binary Trees", "Binary Search Trees", "Heaps",
            "Graphs", "Tries", "Bloom Filters", "Skip Lists", "B-Trees",
            "Red-Black Trees", "AVL Trees", "Disjoint Sets", "Priority Queues"
        ],
        "Algorithms": [
            "Binary Search", "Bubble Sort", "Quick Sort", "Merge Sort",
            "Insertion Sort", "Selection Sort", "Heap Sort", "Breadth-First Search",
            "Depth-First Search", "Dijkstra's Algorithm", "A* Algorithm",
            "Dynamic Programming", "Greedy Algorithms", "Backtracking",
            "Divide and Conquer", "Recursion", "Hashing Algorithms"
        ],
        "Computer Networks": [
            "Ethernet", "Wi-Fi", "Bluetooth", "TCP", "UDP", "IP", "ICMP",
            "ARP", "DHCP", "NAT", "Subnetting", "Routing", "Switching",
            "VLANs", "VPNs", "Firewalls", "DNS", "HTTP", "FTP", "SMTP",
            "POP3", "IMAP", "SSH", "TLS/SSL", "BGP", "OSPF", "MPLS"
        ]
    }
    
    # Get templates and concepts for this subject
    subject_templates = templates.get(subject, templates["Internet Technology"])
    subject_concepts = concepts.get(subject, concepts["Internet Technology"])
    
    # Generate questions
    for i in range(DEFAULT_QUESTIONS_PER_LECTURE):
        # Select a random concept and an alternative concept
        concept = random.choice(subject_concepts)
        alt_concept = random.choice([c for c in subject_concepts if c != concept])
        
        # Select a random template and format it
        template = random.choice(subject_templates)
        question_text = template.format(concept=concept, alt_concept=alt_concept)
        
        # Generate options (1 correct, 3 incorrect)
        correct_option = generate_answer(subject, concept)
        incorrect_options = [
            generate_wrong_answer(subject, concept, correct_option),
            generate_wrong_answer(subject, concept, correct_option),
            generate_wrong_answer(subject, concept, correct_option)
        ]
        
        # Randomize options order
        options = [correct_option] + incorrect_options
        random.shuffle(options)
        
        # Find the index of the correct answer
        correct_index = options.index(correct_option)
        
        # Generate an explanation
        explanation = generate_explanation(subject, concept, correct_option)
        
        # Add the question
        questions.append({
            "text": question_text,
            "options": options,
            "correct": correct_index,
            "explanation": explanation
        })
    
    return questions

def generate_answer(subject, concept):
    """Generate a plausible correct answer for a given subject and concept."""
    answers = {
        "Internet Technology": {
            "HTTP": "Hypertext Transfer Protocol for web communication",
            "HTTPS": "Secure HTTP with TLS encryption",
            "DNS": "Domain Name System for resolving hostnames to IP addresses",
            "TCP/IP": "Transmission Control Protocol/Internet Protocol suite",
            "REST API": "Representational State Transfer architectural style",
            "WebSockets": "Protocol providing full-duplex communication channels",
            "HTTP/2": "Binary protocol with multiplexing and header compression",
            "HTTP/3": "HTTP over QUIC for improved performance",
            "CDN": "Content Delivery Network for distributed content serving",
            "SSL/TLS": "Secure Sockets Layer/Transport Layer Security protocols",
            "Cookies": "Small pieces of data stored by the browser",
            "Web Caching": "Storing copies of files to reduce bandwidth usage"
        },
        "Software Engineering": {
            "Agile": "Iterative approach focusing on collaboration and customer feedback",
            "Scrum": "Framework for managing complex product development",
            "Waterfall": "Linear sequential approach to software development",
            "DevOps": "Practices combining software development and IT operations",
            "CI/CD": "Continuous Integration and Continuous Delivery/Deployment",
            "TDD": "Test-Driven Development methodology",
            "BDD": "Behavior-Driven Development methodology",
            "Version Control": "System for tracking changes to source code",
            "Git": "Distributed version control system",
            "Code Reviews": "Systematic examination of code by peers",
            "Pair Programming": "Two programmers working together at one workstation"
        },
        "Data Structures": {
            "Arrays": "Collection of elements stored at contiguous memory locations",
            "Linked Lists": "Linear collection of elements with pointers to the next node",
            "Stacks": "LIFO (Last In, First Out) data structure",
            "Queues": "FIFO (First In, First Out) data structure",
            "Hash Tables": "Data structure implementing an associative array",
            "Trees": "Hierarchical data structure with a root node and child nodes",
            "Binary Trees": "Tree data structure where each node has at most two children",
            "Binary Search Trees": "Binary tree with ordered nodes for efficient searching",
            "Heaps": "Specialized tree-based data structure satisfying the heap property",
            "Graphs": "Collection of nodes connected by edges"
        },
        "Algorithms": {
            "Binary Search": "O(log n) search algorithm for sorted arrays",
            "Bubble Sort": "Simple comparison-based sorting algorithm",
            "Quick Sort": "Efficient divide-and-conquer sorting algorithm",
            "Merge Sort": "Stable, divide-and-conquer sorting algorithm",
            "Insertion Sort": "Simple sorting algorithm building the final sorted array",
            "Selection Sort": "In-place comparison sorting algorithm",
            "Heap Sort": "Comparison-based sorting algorithm using a heap data structure",
            "Breadth-First Search": "Algorithm for traversing graph data structures",
            "Depth-First Search": "Algorithm for traversing tree or graph data structures",
            "Dijkstra's Algorithm": "Algorithm for finding shortest paths in a graph"
        },
        "Computer Networks": {
            "Ethernet": "Link layer protocol for local area networks",
            "Wi-Fi": "Wireless networking technology based on IEEE 802.11 standards",
            "Bluetooth": "Wireless technology for exchanging data over short distances",
            "TCP": "Connection-oriented transmission protocol",
            "UDP": "Connectionless transmission protocol",
            "IP": "Internet Protocol for packet-switched internetworks",
            "ICMP": "Internet Control Message Protocol for error reporting",
            "ARP": "Address Resolution Protocol for mapping IP addresses to MAC addresses",
            "DHCP": "Dynamic Host Configuration Protocol for IP address assignment",
            "NAT": "Network Address Translation for IP address conservation"
        }
    }
    
    # Get the answer for this concept if available, otherwise generate a generic one
    subject_answers = answers.get(subject, {})
    return subject_answers.get(concept, f"The correct implementation of {concept}")

def generate_wrong_answer(subject, concept, correct_answer):
    """Generate a plausible but incorrect answer."""
    # List of wrong answer templates
    templates = [
        "An outdated approach to {concept} no longer in use",
        "A theoretical concept related to {concept} but never implemented",
        "The opposite of what {concept} actually does",
        "{concept} but with significant security vulnerabilities",
        "A proprietary version of {concept} with limited compatibility",
        "A common misconception about how {concept} works",
        "A deprecated feature of {concept} from earlier versions",
        "An experimental extension to {concept} not widely adopted",
        "A competing standard to {concept} that failed to gain traction",
        "A simplified version of {concept} used only for teaching purposes"
    ]
    
    # Generate a wrong answer that's different from the correct one
    while True:
        wrong_answer = random.choice(templates).format(concept=concept)
        if wrong_answer != correct_answer:
            return wrong_answer

def generate_explanation(subject, concept, correct_answer):
    """Generate an explanation for the correct answer."""
    templates = [
        "{concept} is a fundamental part of {subject}, specifically {correct_answer}.",
        "The correct answer is {correct_answer}. This is a key concept in {subject}.",
        "{correct_answer} is the accurate description of {concept} in {subject}.",
        "In {subject}, {concept} refers to {correct_answer}, which is essential to understand.",
        "{concept} is defined as {correct_answer} in the context of {subject}."
    ]
    
    return random.choice(templates).format(
        concept=concept,
        subject=subject,
        correct_answer=correct_answer
    )

def get_subjects():
    """Get list of available subjects."""
    subjects = []
    for item in QUESTIONS_DIR.iterdir():
        if item.is_dir():
            subject_name = item.name.replace("_", " ").title()
            subjects.append(subject_name)
    return subjects if subjects else DEFAULT_SUBJECTS

def get_lectures_for_subject(subject):
    """Get available lectures for a subject."""
    subject_dir = QUESTIONS_DIR / subject.lower().replace(" ", "_")
    if not subject_dir.exists():
        return []
    
    lectures = []
    for item in subject_dir.iterdir():
        if item.is_file() and item.suffix == '.json' and item.name.startswith('lecture'):
            try:
                lecture_num = int(item.stem.replace('lecture', ''))
                lectures.append(lecture_num)
            except ValueError:
                continue
    
    return sorted(lectures)

def load_questions(subject, lecture_num):
    """Load questions for a specific subject and lecture."""
    subject_dir = QUESTIONS_DIR / subject.lower().replace(" ", "_")
    lecture_file = subject_dir / f"lecture{lecture_num}.json"
    
    if not lecture_file.exists():
        return None
    
    with open(lecture_file, 'r', encoding='utf-8') as f:
        return json.load(f)

def load_leaderboard():
    """Load the current leaderboard."""
    if not LEADERBOARD_FILE.exists():
        current_month = datetime.now().strftime("%Y-%B")
        return {"version": current_month, "users": {}}
    
    with open(LEADERBOARD_FILE, 'r', encoding='utf-8') as f:
        leaderboard = json.load(f)
    
    # Check if we need to reset for a new month
    current_month = datetime.now().strftime("%Y-%B")
    if leaderboard.get("version") != current_month:
        leaderboard = {"version": current_month, "users": {}}
    
    return leaderboard

def save_leaderboard(leaderboard):
    """Save the leaderboard to file."""
    with open(LEADERBOARD_FILE, 'w', encoding='utf-8') as f:
        json.dump(leaderboard, f, indent=2, ensure_ascii=False)

def update_leaderboard(user_id, user_name, score):
    """Update the leaderboard with a user's score."""
    leaderboard = load_leaderboard()
    
    if str(user_id) not in leaderboard["users"]:
        leaderboard["users"][str(user_id)] = {
            "name": user_name,
            "score": score,
            "last_active": datetime.now().strftime("%Y-%m-%d")
        }
    else:
        leaderboard["users"][str(user_id)]["score"] += score
        leaderboard["users"][str(user_id)]["last_active"] = datetime.now().strftime("%Y-%m-%d")
    
    save_leaderboard(leaderboard)
    
    # Return the user's position in the leaderboard
    sorted_users = sorted(
        leaderboard["users"].items(),
        key=lambda x: x[1]["score"],
        reverse=True
    )
    
    for i, (uid, _) in enumerate(sorted_users):
        if str(uid) == str(user_id):
            return i + 1
    
    return len(sorted_users)

def get_leaderboard_text():
    """Get formatted leaderboard text."""
    leaderboard = load_leaderboard()
    
    if not leaderboard["users"]:
        return "🏆 *Monthly Leaderboard* 🏆\n\nNo participants yet. Be the first!"
    
    sorted_users = sorted(
        leaderboard["users"].items(),
        key=lambda x: x[1]["score"],
        reverse=True
    )
    
    text = f"🏆 *Monthly Leaderboard: {leaderboard['version']}* 🏆\n\n"
    
    for i, (_, user_data) in enumerate(sorted_users[:10]):
        medal = ""
        if i == 0:
            medal = "👑 "
        elif i == 1:
            medal = "🥈 "
        elif i == 2:
            medal = "🥉 "
        
        text += f"{i+1}. {medal}{user_data['name']}: {user_data['score']} points\n"
    
    text += "\nKeep pushing for a better rank next time!"
    return text

def start(update: Update, context: CallbackContext) -> int:
    """Send a message when the command /start is issued."""
    user = update.effective_user
    
    # Create main menu keyboard
    keyboard = [
        [InlineKeyboardButton("Choose Subject 📚", callback_data="choose_subject")],
        [InlineKeyboardButton("Leaderboard 🏆", callback_data="leaderboard")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    update.message.reply_text(
        f"Welcome {user.first_name} to the Academic Quiz Bot! 🎓\n\n"
        f"This bot offers quizzes on various academic subjects with a competitive leaderboard.\n\n"
        f"Each quiz consists of 10 multiple-choice questions with a 30-second time limit per question.\n\n"
        f"Please select an option:",
        reply_markup=reply_markup
    )
    
    return MAIN_MENU

def main_menu(update: Update, context: CallbackContext) -> int:
    """Handle main menu selection."""
    query = update.callback_query
    query.answer()
    
    if query.data == "choose_subject":
        return show_subjects(update, context)
    elif query.data == "leaderboard":
        return show_leaderboard(update, context)
    
    return MAIN_MENU

def show_subjects(update: Update, context: CallbackContext) -> int:
    """Show available subjects."""
    query = update.callback_query
    
    # Get available subjects
    subjects = get_subjects()
    
    # Create keyboard with subjects
    keyboard = []
    for subject in subjects:
        keyboard.append([InlineKeyboardButton(subject, callback_data=f"subject:{subject}")])
    
    # Add back button
    keyboard.append([InlineKeyboardButton("« Back", callback_data="back_to_main")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if query:
        query.edit_message_text(
            text="Please select a subject:",
            reply_markup=reply_markup
        )
    else:
        update.message.reply_text(
            text="Please select a subject:",
            reply_markup=reply_markup
        )
    
    return SUBJECT_SELECTION

def subject_selected(update: Update, context: CallbackContext) -> int:
    """Handle subject selection."""
    query = update.callback_query
    query.answer()
    
    if query.data == "back_to_main":
        return back_to_main_menu(update, context)
    
    # Extract subject from callback data
    subject = query.data.split(":")[1]
    context.user_data["selected_subject"] = subject
    
    # Get available lectures for this subject
    lectures = get_lectures_for_subject(subject)
    
    # Create keyboard with lectures
    keyboard = []
    for i in range(0, len(lectures), 2):
        row = []
        for lecture_num in lectures[i:i+2]:
            row.append(InlineKeyboardButton(
                f"Lecture {lecture_num}",
                callback_data=f"lecture:{lecture_num}"
            ))
        keyboard.append(row)
    
    # Add back button
    keyboard.append([InlineKeyboardButton("« Back", callback_data="back_to_subjects")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    query.edit_message_text(
        text=f"Selected subject: *{subject}*\n\nPlease choose a lecture:",
        reply_markup=reply_markup,
        parse_mode=ParseMode.MARKDOWN
    )
    
    return LECTURE_SELECTION

def lecture_selected(update: Update, context: CallbackContext) -> int:
    """Handle lecture selection and start quiz."""
    query = update.callback_query
    query.answer()
    
    if query.data == "back_to_subjects":
        return show_subjects(update, context)
    
    # Extract lecture number from callback data
    lecture_num = int(query.data.split(":")[1])
    subject = context.user_data["selected_subject"]
    
    # Load questions for this lecture
    lecture_data = load_questions(subject, lecture_num)
    
    if not lecture_data:
        query.edit_message_text(
            text=f"Sorry, no questions found for {subject} Lecture {lecture_num}."
        )
        return MAIN_MENU
    
    # Store quiz data in user context
    context.user_data["quiz"] = {
        "subject": subject,
        "lecture": lecture_num,
        "questions": lecture_data["questions"],
        "current_question": 0,
        "score": 0,
        "answers": []
    }
    
    # Store quiz data in global tracking
    user_id = update.effective_user.id
    active_quizzes[user_id] = context.user_data["quiz"]
    
    # Start the quiz
    return show_question(update, context)

def show_question(update: Update, context: CallbackContext) -> int:
    """Show the current question to the user."""
    query = update.callback_query
    user_id = update.effective_user.id
    
    # Get quiz data
    quiz = context.user_data["quiz"]
    question_idx = quiz["current_question"]
    
    # Check if we've reached the end of the quiz
    if question_idx >= len(quiz["questions"]):
        return end_quiz(update, context)
    
    # Get the current question
    question = quiz["questions"][question_idx]
    
    # Create keyboard with options
    keyboard = []
    for i, option in enumerate(question["options"]):
        keyboard.append([InlineKeyboardButton(
            f"{chr(65+i)}. {option}",
            callback_data=f"answer:{i}"
        )])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Format the message
    message_text = (
        f"*{quiz['subject']} - Lecture {quiz['lecture']}*\n\n"
        f"*Question {question_idx + 1} of {len(quiz['questions'])}*\n\n"
        f"{question['text']}\n\n"
        f"Time remaining: {QUESTION_TIMER_DURATION} seconds"
    )
    
    if query:
        query.edit_message_text(
            text=message_text,
            reply_markup=reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
    else:
        # This is for the first question
        context.bot.send_message(
            chat_id=user_id,
            text=message_text,
            reply_markup=reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
    
    # Set a timer for this question
    if user_id in question_timers:
        question_timers[user_id].cancel()
    
    timer = Timer(
        QUESTION_TIMER_DURATION,
        timeout_question,
        args=[context.bot, user_id, question_idx]
    )
    timer.start()
    question_timers[user_id] = timer
    
    return QUIZ_RUNNING

def answer_selected(update: Update, context: CallbackContext) -> int:
    """Handle the user's answer selection."""
    query = update.callback_query
    query.answer()
    user_id = update.effective_user.id
    
    # Cancel the timer for this question
    if user_id in question_timers:
        question_timers[user_id].cancel()
        del question_timers[user_id]
    
    # Extract the selected answer
    selected_option = int(query.data.split(":")[1])
    
    # Get quiz data
    quiz = context.user_data["quiz"]
    question_idx = quiz["current_question"]
    question = quiz["questions"][question_idx]
    
    # Check if the answer is correct
    is_correct = selected_option == question["correct"]
    
    # Update score
    if is_correct:
        quiz["score"] += 1
    
    # Store the answer
    quiz["answers"].append({
        "question_idx": question_idx,
        "selected": selected_option,
        "correct": question["correct"],
        "is_correct": is_correct
    })
    
    # Show feedback
    correct_option = question["options"][question["correct"]]
    selected_text = question["options"][selected_option]
    
    if is_correct:
        feedback = f"✅ Correct! {selected_text}"
    else:
        feedback = f"❌ Wrong! The correct answer is:\n{correct_option}"
    
    # Add explanation if available
    if "explanation" in question:
        feedback += f"\n\n*Explanation:*\n{question['explanation']}"
    
    query.edit_message_text(
        text=feedback,
        parse_mode=ParseMode.MARKDOWN
    )
    
    # Move to the next question after a short delay
    quiz["current_question"] += 1
    context.job_queue.run_once(
        lambda _: show_question(update, context),
        3  # 3 seconds delay
    )
    
    return QUIZ_RUNNING

def timeout_question(bot, user_id, question_idx):
    """Handle question timeout."""
    # Check if the user is still in an active quiz
    if user_id not in active_quizzes:
        return
    
    quiz = active_quizzes[user_id]
    
    # Check if the user has already answered this question
    if quiz["current_question"] != question_idx:
        return
    
    # Get the current question
    question = quiz["questions"][question_idx]
    
    # Store the timeout as an incorrect answer
    quiz["answers"].append({
        "question_idx": question_idx,
        "selected": None,
        "correct": question["correct"],
        "is_correct": False,
        "timeout": True
    })
    
    # Show timeout message
    correct_option = question["options"][question["correct"]]
    
    bot.send_message(
        chat_id=user_id,
        text=f"⏱ Time's up! You didn't answer in time.\n\n"
             f"The correct answer is:\n{correct_option}",
        parse_mode=ParseMode.MARKDOWN
    )
    
    # Move to the next question after a short delay
    quiz["current_question"] += 1
    
    # Schedule showing the next question
    Timer(
        3,  # 3 seconds delay
        lambda: bot.send_message(
            chat_id=user_id,
            text="Moving to the next question..."
        )
    ).start()
    
    # We need to create a dummy update to call show_question
    # This is a workaround since we're outside the normal handler flow
    class DummyUpdate:
        class DummyEffectiveUser:
            id = user_id
        
        class DummyCallbackQuery:
            def edit_message_text(self, **kwargs):
                bot.send_message(chat_id=user_id, **kwargs)
        
        effective_user = DummyEffectiveUser()
        callback_query = DummyCallbackQuery()
    
    class DummyContext:
        class DummyBot:
            def send_message(self, **kwargs):
                bot.send_message(**kwargs)
        
        bot = DummyBot()
        user_data = {"quiz": quiz}
    
    # Schedule showing the next question
    Timer(
        4,  # 4 seconds delay
        show_question,
        args=[DummyUpdate(), DummyContext()]
    ).start()

def end_quiz(update: Update, context: CallbackContext) -> int:
    """End the quiz and show results."""
    user = update.effective_user
    user_id = user.id
    
    # Get quiz data
    quiz = context.user_data["quiz"]
    
    # Calculate score
    total_questions = len(quiz["questions"])
    correct_answers = quiz["score"]
    
    # Update leaderboard
    position = update_leaderboard(user_id, user.first_name, correct_answers)
    
    # Generate response based on score
    if correct_answers == total_questions:
        responses = SCORE_RESPONSES["perfect"]
    elif correct_answers >= total_questions * 0.7:
        responses = SCORE_RESPONSES["good"]
    elif correct_answers >= total_questions * 0.4:
        responses = SCORE_RESPONSES["average"]
    else:
        responses = SCORE_RESPONSES["poor"]
    
    response = random.choice(responses).format(position=position)
    
    # Create keyboard for main menu
    keyboard = [
        [InlineKeyboardButton("Try Another Quiz 📚", callback_data="choose_subject")],
        [InlineKeyboardButton("View Leaderboard 🏆", callback_data="leaderboard")],
        [InlineKeyboardButton("Main Menu 🏠", callback_data="back_to_main")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Send results message
    if update.callback_query:
        update.callback_query.edit_message_text(
            text=f"*Quiz Completed!*\n\n"
                 f"Subject: {quiz['subject']}\n"
                 f"Lecture: {quiz['lecture']}\n\n"
                 f"Your Score: {correct_answers}/{total_questions}\n\n"
                 f"{response}",
            reply_markup=reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
    else:
        context.bot.send_message(
            chat_id=user_id,
            text=f"*Quiz Completed!*\n\n"
                 f"Subject: {quiz['subject']}\n"
                 f"Lecture: {quiz['lecture']}\n\n"
                 f"Your Score: {correct_answers}/{total_questions}\n\n"
                 f"{response}",
            reply_markup=reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
    
    # Clean up
    if user_id in active_quizzes:
        del active_quizzes[user_id]
    
    if user_id in question_timers:
        question_timers[user_id].cancel()
        del question_timers[user_id]
    
    return MAIN_MENU

def show_leaderboard(update: Update, context: CallbackContext) -> int:
    """Show the leaderboard."""
    query = update.callback_query
    
    leaderboard_text = get_leaderboard_text()
    
    # Create keyboard for back button
    keyboard = [[InlineKeyboardButton("« Back", callback_data="back_to_main")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if query:
        query.edit_message_text(
            text=leaderboard_text,
            reply_markup=reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
    else:
        update.message.reply_text(
            text=leaderboard_text,
            reply_markup=reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
    
    return MAIN_MENU

def back_to_main_menu(update: Update, context: CallbackContext) -> int:
    """Return to the main menu."""
    query = update.callback_query
    
    # Create main menu keyboard
    keyboard = [
        [InlineKeyboardButton("Choose Subject 📚", callback_data="choose_subject")],
        [InlineKeyboardButton("Leaderboard 🏆", callback_data="leaderboard")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    query.edit_message_text(
        text="Welcome to the Academic Quiz Bot! 🎓\n\n"
             "Please select an option:",
        reply_markup=reply_markup
    )
    
    return MAIN_MENU

def help_command(update: Update, context: CallbackContext) -> None:
    """Send a message when the command /help is issued."""
    update.message.reply_text(
        "This bot offers academic quizzes with a competitive leaderboard.\n\n"
        "Available commands:\n"
        "/start - Start the bot and show main menu\n"
        "/help - Show this help message\n"
        "/subjects - Show available subjects\n"
        "/leaderboard - Show the current leaderboard\n\n"
        "Each quiz consists of 10 multiple-choice questions with a 30-second time limit per question."
    )

def subjects_command(update: Update, context: CallbackContext) -> int:
    """Handle /subjects command."""
    return show_subjects(update, context)

def leaderboard_command(update: Update, context: CallbackContext) -> int:
    """Handle /leaderboard command."""
    update.message.reply_text(get_leaderboard_text(), parse_mode=ParseMode.MARKDOWN)
    return ConversationHandler.END

def error_handler(update: Update, context: CallbackContext) -> None:
    """Handle errors."""
    logger.error(f"Error: {context.error} caused by {update}")

def main() -> None:
    """Start the bot."""
    # Initialize quiz data
    init_quiz_data()
    
    # Create the Updater and pass it your bot's token
    updater = Updater(os.environ.get("TELEGRAM_TOKEN", "YOUR_TOKEN_HERE"))
    
    # Get the dispatcher to register handlers
    dispatcher = updater.dispatcher
    
    # Add conversation handler
    conv_handler = ConversationHandler(
        entry_points=[
            CommandHandler("start", start),
            CommandHandler("subjects", subjects_command),
        ],
        states={
            MAIN_MENU: [
                CallbackQueryHandler(main_menu)
            ],
            SUBJECT_SELECTION: [
                CallbackQueryHandler(subject_selected)
            ],
            LECTURE_SELECTION: [
                CallbackQueryHandler(lecture_selected)
            ],
            QUIZ_RUNNING: [
                CallbackQueryHandler(answer_selected)
            ],
        },
        fallbacks=[CommandHandler("start", start)],
    )
    
    dispatcher.add_handler(conv_handler)
    
    # Add standalone command handlers
    dispatcher.add_handler(CommandHandler("help", help_command))
    dispatcher.add_handler(CommandHandler("leaderboard", leaderboard_command))
    
    # Add error handler
    dispatcher.add_error_handler(error_handler)
    
    # Start the Bot
    updater.start_polling()
    
    # Run the bot until you press Ctrl-C
    updater.idle()

if __name__ == '__main__':
    main()
