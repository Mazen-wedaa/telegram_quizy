# Academic Quiz Bot - User Guide

## Overview

This Telegram bot provides structured academic quizzes with a competitive leaderboard system. It features:

- 5 academic subjects
- 14 lectures per subject (configurable)
- 10 multiple-choice questions per lecture
- 30-second timer per question
- Dynamic leaderboard with monthly reset

## How to Use the Bot

1. **Start the Bot**:
   - Search for your bot on Telegram (using the username you created with BotFather)
   - Start a conversation with the bot by clicking "Start" or sending `/start`

2. **Main Menu**:
   - The bot will present two main options:
     - "Choose Subject 📚" - Browse available academic subjects
     - "Leaderboard 🏆" - View the current monthly leaderboard

3. **Taking a Quiz**:
   - Select "Choose Subject 📚" from the main menu
   - Choose one of the 5 academic subjects
   - Select a specific lecture (1-14)
   - Answer the 10 multiple-choice questions within the 30-second time limit for each
   - After completing all questions, you'll see your score and position on the leaderboard

4. **Viewing the Leaderboard**:
   - Select "Leaderboard 🏆" from the main menu
   - The leaderboard shows the top 10 participants for the current month
   - Top 3 participants receive special medals (👑, 🥈, 🥉)

5. **Additional Commands**:
   - `/start` - Return to the main menu
   - `/help` - Display help information
   - `/subjects` - Show available subjects directly
   - `/leaderboard` - View the current leaderboard directly

## Quiz Flow

1. Select a subject
2. Choose a lecture
3. Answer 10 multiple-choice questions (30 seconds per question)
4. Receive immediate feedback after each answer
5. View your final score and leaderboard position
6. Choose to try another quiz or return to the main menu

## Leaderboard System

- Scores are accumulated throughout the month
- Leaderboard resets at the beginning of each month
- Your position is determined by your total score
- The more quizzes you take and questions you answer correctly, the higher your ranking

## Technical Information

The bot is hosted on PythonAnywhere and runs 24/7. It stores quiz data and leaderboard information in JSON files.

Enjoy learning with the Academic Quiz Bot!
