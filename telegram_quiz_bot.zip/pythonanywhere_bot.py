#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
PythonAnywhere configuration script for the Academic Quiz Bot.
This script sets up the environment and runs the bot on PythonAnywhere.
"""

import os
import sys
from pathlib import Path

# Set the Telegram token as an environment variable
os.environ["TELEGRAM_TOKEN"] = "7880947646:AAHGXQePLW3d-NNe0vKRpCFn1nWYPrZCMJA"

# Import and run the main bot script
sys.path.append(str(Path(__file__).resolve().parent))
from main import main

if __name__ == "__main__":
    # Create necessary directories
    quiz_data_dir = Path(__file__).resolve().parent / "quiz_data"
    questions_dir = quiz_data_dir / "questions"
    
    quiz_data_dir.mkdir(exist_ok=True)
    questions_dir.mkdir(exist_ok=True)
    
    # Start the bot
    main()
